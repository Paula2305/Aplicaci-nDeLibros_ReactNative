import React, { useState } from 'react';
import { Input, Stack, FormControl, Box, Button } from 'native-base';

export const BookForm = (route) => {
    const {creatingBook} = route.params;

    const [formData, setFormData] = useState({
        titulo: '',
        autor: '',
        isbn: '',
        precio: '',
        genero: '',
        sinopsis: '',
        foto: ''
    })

    const handlePublicarLibro = () => {
        if (creatingBook){
            const newBook = {...formData}
        }
        // Definir el comportamiento del boton en base al parametro que llegue CreatingBook true or false 
    }

    return (
        <Box /* style={{ width: '90%', height: '80%', margin: '5%' }} */
            maxWidth={'90%'}
            height={'80%'}
            margin={'5%'}
        >
            <FormControl>
                <Stack space={5}>
                    <Stack>
                        <FormControl.Label>Titulo</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="Ej: Señor de los anillos" value = {formData.titulo} />
                    </Stack>
                    <Stack>
                        <FormControl.Label>Autor</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="Ej: Tolkien" value = {formData.autor} />
                    </Stack>
                    <Stack>
                        <FormControl.Label>ISBN</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="Ej: 559873" value = {formData.isbn}/>
                    </Stack>
                    <Stack>
                        <FormControl.Label>Precio</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="$" value = {formData.precio}/>
                    </Stack>
                    <Stack>
                        <FormControl.Label>Genero</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="Ej: Ficcion" value = {formData.genero}/>
                    </Stack>
                    <Stack>
                        <FormControl.Label>Sinopsis</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="Ej: Sinopsis" value = {formData.sinopsis} />
                    </Stack>
                    <Stack>
                        <FormControl.Label>Foto</FormControl.Label>
                        <Input variant="underlined" p={2} placeholder="img" value = {formData.foto}/>
                    </Stack>
                </Stack>
            </FormControl>

            <Button
                maxWidth={40}
                my={10}
                onPress={() => handlePublicarLibro}>Publicar</Button> 
        </Box>

    )
}

export default BookForm